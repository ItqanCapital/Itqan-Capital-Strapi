'use strict';

/**
 * companies-login router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::companies-login.companies-login');
