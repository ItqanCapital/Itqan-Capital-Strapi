'use strict';

/**
 * companies-login service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::companies-login.companies-login');
