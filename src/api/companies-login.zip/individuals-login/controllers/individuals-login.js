'use strict';

/**
 * individuals-login controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::individuals-login.individuals-login');
