'use strict';

/**
 * individuals-login router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::individuals-login.individuals-login');
