'use strict';

/**
 * individuals-login service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::individuals-login.individuals-login');
